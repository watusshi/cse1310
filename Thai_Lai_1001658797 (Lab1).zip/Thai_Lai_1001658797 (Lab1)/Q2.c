//Thai Lai
//1001658797
//Lab1 (CSE-1310-007)
//Professor Bhanu Jain
//Time taken: 5min

#include <stdio.h>
#include <math.h>

int main() {
	double leg_a = 3; //variable leg_a declared
	double leg_b = 4; //variable leg_b declared
	double area = (leg_a * leg_b)/2; //variable area declared with calculations
	double c2 = pow(leg_a,2)+pow(leg_b,2); //variable c2 declared with calculations

	printf("%0.1f\n",area); //print out the value of area
	printf("%0.1f\n",c2); //print out the value of c2

	return 0;
}

/**HONOR CODE
I plege, on my honor, to uphold UT Arlington's tradion of academic 
intergrity, a tradition that values hard work and honest effort in the pursuit
of acdemic excellence.
I promise that I will submit only work that I personally create or that
I contribute to group collaborations, and I will appropriately reference
any work from other sources. I will follow the highest standards of 
integrity and upholdthe spirit of the Honor Code.
I will not engage in any form of cheating.

Thai Lai
1001658797
**/
