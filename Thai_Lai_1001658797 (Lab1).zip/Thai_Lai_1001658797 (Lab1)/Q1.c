//Thai Lai
//1001658797
//Lab1 (CSE-1310-007)
//Professor Bhanu Jain
//Time take: 5min

#include <stdio.h>

int main() {
	int side = 3; //variable side declared 
	double perimeter = 3*side; //variable perimeter declared with calculations
	double area = 0.433*side*side; //variable area declared with calculations

	printf("%0.1f\n",perimeter); //print out the value of perimeter
	printf("%0.1f\n", area); //print out the value of area

	return 0;
}

/**HONOR CODE
I plege, on my honor, to uphold UT Arlington's tradion of academic 
intergrity, a tradition that values hard work and honest effort in the pursuit
of acdemic excellence.
I promise that I will submit only work that I personally create or that
I contribute to group collaborations, and I will appropriately reference
any work from other sources. I will follow the highest standards of 
integrity and upholdthe spirit of the Honor Code.
I will not engage in any form of cheating.

Thai Lai
1001658797
**/