//Thai Lai
//1001658797
//Lab1 (CSE-1310-007)
//Professor Bhanu Jain


#include <stdio.h>

int main () {
	double base_a = 3; //variable base_a declared
	double base_b = 5; //variable base_b declared
	double height = 4; //variable height declared

	double area = (base_a+base_b)*height/2; //variable area declared with the calculations

	printf("%0.1f\n", area); //print out the value of area

	return 0;
}

/**HONOR CODE
I plege, on my honor, to uphold UT Arlington's tradion of academic 
intergrity, a tradition that values hard work and honest effort in the pursuit
of acdemic excellence.
I promise that I will submit only work that I personally create or that
I contribute to group collaborations, and I will appropriately reference
any work from other sources. I will follow the highest standards of 
integrity and upholdthe spirit of the Honor Code.
I will not engage in any form of cheating.

Thai Lai
1001658797
**/